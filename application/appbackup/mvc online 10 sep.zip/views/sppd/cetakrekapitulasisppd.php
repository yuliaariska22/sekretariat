<html>
<head>
<style>
@media print 
{
   @page 

   {
    size: 12.99in 8.27in;
  }
}
.jarak-lh{
  line-height:10px;
}
.jarak-namaopd{
  margin:0px;
  padding:0px;
}
p {
    font-size: 12spt;
}
table{
    font-size: 12pt;
    border-collapse: collapse;
}
h2{
    text-transform: uppercase;
}
.capslock{
    text-transform: uppercase;
}
</style>
<center>
REKAPITULASI SPPD TAHUN ANGGARAN <?php echo date('Y');?><Br>
<p class="capslock"> PADA <?= $opd->nama_opd ?> KOTA PADANGSIDIMPUAN<Br></p>
UNTUK GANTI UANG (GU)/TAMBAHAN UANG NIHIL (TU-NIHIL)/GANTI UANG NIHIL (GU-NIHIL) KE - ....<br>
</center>
</head>

<body>
<br>
<table width="100%" border="1">
<tr>
<td rowspan="2" align="center">No</td>
<td rowspan="2" align="center">Nama</td>
<td rowspan="2" align="center">Jabatan</td>
<td rowspan="2" align="center">Gol</td>
<td rowspan="2" align="center">No. BKU</td>
<td colspan="2" align="center">SPPD</td>
<td rowspan="2" align="center">Jlh Hari</td>
<td rowspan="2" align="center">Tanggal Berangkat</td>
<td rowspan="2" align="center">Tanggal Pulang</td>
<td rowspan="2" align="center">Kota Asal</td>
<td rowspan="2" align="center">Kota Tujuan</td>
<td colspan="7" align="center">Biaya Perjalanan Dinas</td>
<td rowspan="2" align="center">Biaya Kontibusi</td>
</tr>
<tr>
<td align="center">Nomor</td>
<td align="center">Tanggal</td>
<td align="center">Uang Harian</td>
<td align="center">Representasi</td>
<td align="center">Tiket Angk. Darat</td>
<td align="center">Tiket Pesawat</td>
<td align="center">Taxi</td>
<td align="center">Airport Tax</td>
<td align="center">Jumlah</td>
</tr>

<?php 
                  $no = 1;
                  $jumlah_biayaperjalanandinas = 0;
                  
                  $total_uangharian =0;
                  $total_representasi =0;
                  $total_tiket_angkutan_darat =0;
                  $total_tiketpesawat =0;
                  $total_taxi =0;
                  $total_taxes =0;
                  $total_biaya_kontribusi =0;
                  $total_keseluruhan =0;
                  foreach ($daftarpengeluaran as $data) : 
                  ?> 
                  <tr>
                    <td align="center"><?= $no?></td>
                    <td align="center"><?= $data->nama?></td>
                    <td><?= $data->jabatan?></td>
                    <td align="center"><?= $data->gol?></td>
                    <td align="center"><?= $data->no_bku?></td>
                    <td align="center"><?= $data->no_sppd?></td> 
                    <td align="center"><?= format_indo(date($data->tanggal_sppd))?></td>
                    <td align="center">
                    <?php 
                    $tgl1 = new DateTime("$data->tanggal_berangkat");
                    $tgl2 = new DateTime("$data->tanggal_kembali");
                    $jarak = $tgl2->diff($tgl1);

                    echo $jarak->d;?> Hari
                    </td>
                    <td align="center"><?= format_indo(date($data->tanggal_berangkat))?></td>
                    <td align="center"><?= format_indo(date($data->tanggal_kembali))?></td>
                    <td align="center"><?= $data->kota_berangkat?></td>
                    <td align="center"><?= $data->kota_tujuan?></td>
                    <td align="right"><?= 'Rp. '.number_format(($data->uangharian),0,'.','.').',-'; ?></td>
                    <td align="right"><?= 'Rp. '.number_format(($data->representasi),0,'.','.').',-'; ?></td>
                    <td align="right"><?= 'Rp. '.number_format(($data->tiket_angkutan_darat),0,'.','.').',-'; ?></td>
                    <td align="right"><?= 'Rp. '.number_format(($data->keb_basicfare+$data->ked_basicfare),0,'.','.').',-'; ?></td>
                    <td align="right"><?= 'Rp. '.number_format(($data->taxi),0,'.','.').',-'; ?></td>
                    <td align="right"><?= 'Rp. '.number_format(($data->keb_taxes+$data->ked_taxes),0,'.','.').',-'; ?></td>
                    <?php 
                    $jumlah_biayaperjalanandinas =  $data->uangharian+$data->representasi+$data->tiket_angkutan_darat+$data->keb_basicfare+$data->ked_basicfare+$data->taxi+$data->keb_taxes+$data->ked_taxes?>
                    <td align="right"><?= 'Rp. '.number_format(($jumlah_biayaperjalanandinas),0,'.','.').',-'; ?></td>
                    <td align="right"><?= 'Rp. '.number_format(($data->biaya_kontribusi),0,'.','.').',-'; ?></td>
                  </tr>
                <?php
                      $no++;
                      $total_uangharian += $data->uangharian;
                      $total_representasi += $data->representasi;
                      $total_tiket_angkutan_darat += $data->tiket_angkutan_darat;
                      $total_tiketpesawat += $data->keb_basicfare+$data->ked_basicfare;
                      $total_taxi += $data->taxi;
                      $total_taxes += $data->keb_taxes+$data->ked_taxes;
                      $total_biaya_kontribusi += $data->biaya_kontribusi;
                    endforeach;
                  ?>

<tr>
                    <td colspan="12" align="center">Jumlah</td>
                    <td align="right"><?= 'Rp. '.number_format(($total_uangharian),0,'.','.').',-'; ?></td>
                    <td align="right"><?= 'Rp. '.number_format(($total_representasi),0,'.','.').',-'; ?></td>
                    <td align="right"><?= 'Rp. '.number_format(($total_tiket_angkutan_darat),0,'.','.').',-'; ?></td>
                    <td align="right"><?= 'Rp. '.number_format(($total_tiketpesawat),0,'.','.').',-'; ?></td>
                    <td align="right"><?= 'Rp. '.number_format(($total_taxi),0,'.','.').',-'; ?></td>
                    <td align="right"><?= 'Rp. '.number_format(($total_taxes),0,'.','.').',-'; ?></td>
                    <?php
                    $total_keseluruhan = $total_uangharian +$total_representasi +$total_tiket_angkutan_darat +$total_tiketpesawat +$total_taxi +$total_taxes
                    ?>
                    <td align="right"><?= 'Rp. '.number_format(($total_keseluruhan),0,'.','.').',-'; ?></td>
                    <td align="right"><?= 'Rp. '.number_format(($total_biaya_kontribusi),0,'.','.').',-'; ?></td>
                  </tr>
</table>

<table width="100%">
<tr><td><br></td></tr>

<tr>
<td width="65%"></td>
<td>Jumlah Periode ini : <?= 'Rp. '.number_format(($total_keseluruhan+$total_biaya_kontribusi),0,'.','.').',-'; ?></td>
</tr>

<tr>
<td width="65%"></td>
<?php $jumlah_periode_lalu = $daftarpengeluaran_periodelalu['uangharian']+$daftarpengeluaran_periodelalu['representasi']+$daftarpengeluaran_periodelalu['tiket_angkutan_darat']+$daftarpengeluaran_periodelalu['keb_basicfare']+$daftarpengeluaran_periodelalu['ked_basicfare']+$daftarpengeluaran_periodelalu['ked_taxes']+$daftarpengeluaran_periodelalu['keb_taxes']+$daftarpengeluaran_periodelalu['taxi']+$daftarpengeluaran_periodelalu['biaya_kontribusi'] ; ?>
<td>Jumlah s/d Periode lalu : <?= 'Rp. '.number_format(($jumlah_periode_lalu),0,'.','.').',-'; ?></td>
</tr>

<tr>
<td width="65%"></td>
<?php $jumlah_periode_ini = $daftarpengeluaran_periodeini['uangharian']+$daftarpengeluaran_periodeini['representasi']+$daftarpengeluaran_periodeini['tiket_angkutan_darat']+$daftarpengeluaran_periodeini['keb_basicfare']+$daftarpengeluaran_periodeini['ked_basicfare']+$daftarpengeluaran_periodeini['ked_taxes']+$daftarpengeluaran_periodeini['keb_taxes']+$daftarpengeluaran_periodeini['taxi']+$daftarpengeluaran_periodeini['biaya_kontribusi'] ; ?>
<td>Jumlah s/d Periode ini : <?= 'Rp. '.number_format(($jumlah_periode_ini),0,'.','.').',-'; ?></td>
</tr>
</table>


<div style="page-break-inside:avoid;">
<footer>
<table width="100%">
<tr><td><br><br></td></tr>
<tr>
<td width="65%"></td>
<td>Padangsidimpuan, <?php echo format_indo(date('Y-m-d'));?></td>
</tr>

<tr>
<td><br></td>
</tr>

<tr>
<td width="65%"> Disetujui :</td>
<td>Dibayar Oleh :</td>
</tr>


<tr>
<td width="65%"> PIMPINAN PERANGKAT DAERAH</td>
<td>BENDAHARA PENGELUARAN</td>
</tr>


<tr height="65px">
<td></td>
</tr>


<tr>
<td width="65%"><?= $penggunaanggaran->nama ?></td>
<td><?= $bendahara->nama ?></td>
</tr>

<tr>
<td width="65%">NIP. <?= $penggunaanggaran->nip ?></td>
<td>NIP. <?= $bendahara->nip ?></td>
</tr>
</table>
</footer>
</div>

</html>