<html>
<head>
<style>
@media print 
{
   @page 

   {
    size: 8.27in 12.99in;
  }
}
.jarak-lh{
  line-height:10px;
}
p {
    font-size: 12spt;
}
table{
    font-size: 12pt;
    border-collapse: collapse;
}
</style>
<table align="center">
<tr>
<td>
<img src="<?php echo base_url('theme/logopadsim.jpg')?>" width="100px">
<td>
<td>
<h3 class="jarak-lh" align="center">PEMERINTAH KOTA PADANGSIDIMPUAN</h3>
<h1 class="jarak-lh" align="center">BADAN KEUANGAN DAERAH</h1>
<p class="jarak-lh" align="center">Jln. Jen. Dr. Abd.Haris Nasution Pal - IV Pijorkoling Telp (0634)27075 Fax. (0634) 27075</p>
<p class="jarak-lh" align="center">Kec. Padangsidimpuan Tenggara</p>
<td>
</tr>
<tr>
<td colspan=3>
<hr  color="black" size="2px"/>
</td>
</tr>
</table>
</head>
<br>
<body>
<table  align="right">
<tr><td>Kepada Yth :</td></tr>
<tr><td>Kepala Badan/Dinas/Kantor.....</td></tr>
<tr><td>Selaku Pengguna Anggaran</td></tr>
<tr><td>Di -</td></tr>
<tr><td>&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp Padangsidimpuan</td></tr>
</table>
<table  align="left">
<tr><td>Nomor</td><td>:</td></tr>
<tr><td>Sifat</td><td>:</td></tr>
<tr><td>Lampiran</td><td>:</td></tr>
<tr><td>Perihal</td><td>:</td><td><b>Permohonan uang muka 30%</b></td></tr>
</table>
<br><br><br><br><br><br><br>
<table>
<tr><p><td>Dengan hormat,</p></td></tr>     </table>
<tr><p><td>Bersama ini kami mengajukan Uang Muka 30%sebesar Rp. ................ (......terbilang......). 
Agar kami dapat melaksanakan Pekerjaan : .......................... 
Nomor Kontrak : .............................. tanggal ........................ 
Dengan pelaksana CV/PT ..................... dimana uang tersebut akan dipergunakan untuk pekerjaan ........................... </p></td></tr>     </table>
<table>
<tr><td><p>Demikian permohonan ini kami ajukan, dengan harapan mendapat persetujuan dan kami ucapkan terimakasih. </p></td></tr>   
  </table>                   
</body>
<footer>
<br>
<br><br><br><br><br><br><br><br>
<table align="right">
<tr><td>&nbsp &nbsp &nbsp &nbsp &nbsp    Padangsidimpuan,     2021 </td></tr>
<tr><td>&nbsp &nbsp &nbsp &nbsp &nbsp  UD/CV/PT……..   </td></tr>
</table>
<br><br><br><br><br><br><br><br>
<table align="right">
<tr><td>Nama Direktur </td></tr>
</table>
</footer>

</html>