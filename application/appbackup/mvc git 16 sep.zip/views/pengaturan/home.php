<?php 
$this->load->view('include/header'); 
?>
  <section id="hero">
    <div class="hero-container" data-aos="fade-in">
     
    </div>
  </section><!-- End Hero Section -->

  <main id="main">
  </main>
<?php 
$this->load->view('include/footer'); 
?>  