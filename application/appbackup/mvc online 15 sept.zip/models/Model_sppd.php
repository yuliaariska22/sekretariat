<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_sppd extends CI_Model {

	public function __construct()
	{
		parent::__construct();
        $this->load->library('session');
	}

	public function sppd()
	{
		$nip=$this->session->userdata('nip');

		$this->db->order_by('id_sppd');
		$this->db->where('tbl_sppd.nip', $nip);
        return $this->db->from('tbl_sppd')
			->get();
	}

	public function menambahdatasppd($data)
	{
		$this->db->insert('tbl_sppd', $data);
	}

	public function updatesppd($data, $id_sppd)
	{
		$this->db->where('id_sppd', $id_sppd);
		$this->db->update('tbl_sppd', $data);
	}

	public function deletesppd($id_sppd)
	{
		$this->db->where('id_sppd', $id_sppd);
		$this->db->delete('tbl_sppd');
	}

	public function detailsppd($id_sppd)
	{
		$this->db->where('id_sppd', $id_sppd);
        return $this->db->from('tbl_detailsppd')
			->join('tbl_pegawai','tbl_pegawai.nip=tbl_detailsppd.nip')
			->get();
	}

	public function deletedetailsppd($id_detailsppd)
	{
		$this->db->where('id_detailsppd', $id_detailsppd);
		$this->db->delete('tbl_detailsppd');
	}

	public function menambahdatadetailsppd($data)
	{
		$this->db->insert('tbl_detailsppd', $data);
	}

	public function detailsppdpengikut($id_sppd)
	{
		$this->db->where('id_sppd', $id_sppd);
        return $this->db->from('tbl_detailsppdpengikut')
			->get();
	}

	public function deletedetailsppdpengikut($id_detailsppdpengikut)
	{
		$this->db->where('id_detailsppdpengikut', $id_detailsppdpengikut);
		$this->db->delete('tbl_detailsppdpengikut');
	}

	public function menambahdatadetailsppdpengikut($data)
	{
		$this->db->insert('tbl_detailsppdpengikut', $data);
	}

	public function detailsppdtujuan($id_sppd)
	{
		$this->db->where('id_sppd', $id_sppd);
        return $this->db->from('tbl_detailsppdtujuan')
			->get();
	}

	public function deletedetailsppdtujuan($id_detailsppdtujuan)
	{
		$this->db->where('id_detailsppdtujuan', $id_detailsppdtujuan);
		$this->db->delete('tbl_detailsppdtujuan');
	}

	public function menambahdatadetailsppdtujuan($data)
	{
		$this->db->insert('tbl_detailsppdtujuan', $data);
	}

	public function detailsppddasar($id_sppd)
	{
		$this->db->where('id_sppd', $id_sppd);
        return $this->db->from('tbl_detailsppddasar')
			->get();
	}

	public function deletedetailsppddasar($id_detailsppddasar)
	{
		$this->db->where('id_detailsppddasar', $id_detailsppddasar);
		$this->db->delete('tbl_detailsppddasar');
	}

	public function menambahdatadetailsppddasar($data)
	{
		$this->db->insert('tbl_detailsppddasar', $data);
	}
	public function getupdatesppd($id_sppd)
	{
		$this->db->where('tbl_sppd.id_sppd', $id_sppd);
        return $this->db->from('tbl_sppd')
			->join('tbl_pembebanananggaran','tbl_pembebanananggaran.id_pembebanananggaran=tbl_sppd.pembebanan_anggaran')
			->get();
	}

	public function sppdperorangan()
	{
		$nip=$this->session->userdata('nip');

		$this->db->order_by('id_detailsppd');
		$this->db->where('tbl_detailsppd.nip', $nip);
        return $this->db->from('tbl_detailsppd')
			->join('tbl_sppd','tbl_sppd.id_sppd=tbl_detailsppd.id_sppd')
			->get();
	}

	public function detaillaporan($id_sppd)
	{
		$this->db->where('id_sppd', $id_sppd);
        return $this->db->from('tbl_laporanperjalanandinas')
			->get();
	}

	public function menambahdatalaporanperjalanandinas($data)
	{
		$this->db->insert('tbl_laporanperjalanandinas', $data);
	}

	public function deletelaporanperjalanandinas($id_laporanperjalanandinas)
	{
		$this->db->where('id_laporanperjalanandinas', $id_laporanperjalanandinas);
		$this->db->delete('tbl_laporanperjalanandinas');
	}

	public function detaillaporanmaksud($id_sppd)
	{
		$this->db->where('id_sppd', $id_sppd);
        return $this->db->from('tbl_laporanmaksud')
			->get();
	}

	public function menambahdatalaporanmaksud($data)
	{
		$this->db->insert('tbl_laporanmaksud', $data);
	}

	public function deletelaporanmaksud($id_laporanmaksud)
	{
		$this->db->where('id_laporanmaksud', $id_laporanmaksud);
		$this->db->delete('tbl_laporanmaksud');
	}


	public function detaildaftarpengeluaranrill($id_detailsppd)
	{
		$this->db->where('id_detailsppd', $id_detailsppd);
        return $this->db->from('tbl_daftarpengeluaranrill')
			->join('tbl_ssh','tbl_ssh.id_ssh=tbl_daftarpengeluaranrill.uraian')
			->get();
	}

	public function menambahdatadaftarpengeluaranrill($data)
	{
		$this->db->insert('tbl_daftarpengeluaranrill', $data);
	}

	public function deletedaftarpengeluaranrill($id_daftarpengeluaranrill)
	{
		$this->db->where('id_daftarpengeluaranrill', $id_daftarpengeluaranrill);
		$this->db->delete('tbl_daftarpengeluaranrill');
	}

	public function detaildaftarpengeluaran($id_detailsppd)
	{
		$this->db->where('id_detailsppd', $id_detailsppd);
        return $this->db->from('tbl_daftarpengeluaran')
			->get();
	}

	public function menambahdatadaftarpengeluaran($data)
	{
		$this->db->insert('tbl_daftarpengeluaran', $data);
	}

	public function updatedatadaftarpengeluaran($data, $id_detailsppd)
	{
		$this->db->where('id_detailsppd', $id_detailsppd);
		$this->db->update('tbl_daftarpengeluaran', $data);
	}

	public function deletedaftarpengeluaran($id_daftarpengeluaran)
	{
		$this->db->where('id_daftarpengeluaran', $id_daftarpengeluaran);
		$this->db->delete('tbl_daftarpengeluaran');
	}

	public function cetaksppd($id_sppd)
	{
		$this->db->where('id_sppd', $id_sppd);
		$this->db->order_by('tbl_riwayat_kepangkatan.tanggal_sk', "DESC");
		$this->db->order_by('tbl_riwayat_jabatan.tanggal_sk', "DESC");
		$this->db->limit(1);
        return $this->db->from('tbl_sppd')
		->join('tbl_pegawai','tbl_pegawai.nip=tbl_sppd.nip')
		->join('tbl_riwayat_kepangkatan','tbl_riwayat_kepangkatan.nip=tbl_pegawai.nip')
		->join('tbl_riwayat_jabatan','tbl_riwayat_jabatan.nip=tbl_pegawai.nip')
		->join('tbl_pembebanananggaran','tbl_pembebanananggaran.id_pembebanananggaran=tbl_sppd.pembebanan_anggaran')
			->get()->row();
	}

	public function cetakdetailsppd($id_sppd)
	{
		$this->db->where('id_sppd', $id_sppd);
		$this->db->order_by('tbl_riwayat_kepangkatan.tanggal_sk', "DESC");
		$this->db->order_by('tbl_riwayat_jabatan.tanggal_sk', "DESC");
		$this->db->limit(1);
        return $this->db->from('tbl_detailsppd')
			->join('tbl_pegawai','tbl_pegawai.nip=tbl_detailsppd.nip')
			->join('tbl_riwayat_kepangkatan','tbl_riwayat_kepangkatan.nip=tbl_pegawai.nip')
			->join('tbl_riwayat_jabatan','tbl_riwayat_jabatan.nip=tbl_pegawai.nip')
			->get()->result();
	}

	public function cetakdetailsppddasar($id_sppd)
	{
		$this->db->where('id_sppd', $id_sppd);
        return $this->db->from('tbl_detailsppddasar')
			->get()->result();
	}

	public function cetakdetailsppdpengikut($id_sppd)
	{
		$this->db->where('id_sppd', $id_sppd);
        return $this->db->from('tbl_detailsppdpengikut')
			->get()->result();
	}
	public function cetakdetailsppdtujuan($id_sppd)
	{
		$this->db->where('id_sppd', $id_sppd);
        return $this->db->from('tbl_detailsppdtujuan')
			->get()->result();
	}

	public function cetakdetailsppdtujuansatu($id_sppd)
	{
		$this->db->where('id_sppd', $id_sppd);
		$this->db->limit(1);
        return $this->db->from('tbl_detailsppdtujuan')
			->get()->result();
	}
	
	public function cetakdetaillaporan($id_sppd)
	{
		$this->db->where('id_sppd', $id_sppd);
        return $this->db->from('tbl_laporanperjalanandinas')
			->get()->result();
	}

	public function cetakdetailbiaya($id_sppd)
	{
		$nip = $this->session->userdata('nip');
		$this->db->where('tbl_sppd.id_sppd', $id_sppd);
		$this->db->where('tbl_detailsppd.nip', $nip);
        return $this->db->from('tbl_daftarpengeluaranrill')
			->join('tbl_detailsppd','tbl_detailsppd.id_detailsppd=tbl_daftarpengeluaranrill.id_detailsppd')
			->join('tbl_sppd','tbl_sppd.id_sppd=tbl_detailsppd.id_sppd')
			->join('tbl_ssh','tbl_ssh.id_ssh=tbl_daftarpengeluaranrill.uraian')
			->get()->result();
	}

	public function cetakdetailbiayarill($id_sppd)
	{
		$nip = $this->session->userdata('nip');
		$this->db->where('tbl_sppd.id_sppd', $id_sppd);
		$this->db->where('tbl_detailsppd.nip', $nip);
		$this->db->where('tbl_daftarpengeluaranrill.bukti', 'Tidak Ada');
        return $this->db->from('tbl_daftarpengeluaranrill')
			->join('tbl_detailsppd','tbl_detailsppd.id_detailsppd=tbl_daftarpengeluaranrill.id_detailsppd')
			->join('tbl_sppd','tbl_sppd.id_sppd=tbl_detailsppd.id_sppd')
			->join('tbl_ssh','tbl_ssh.id_ssh=tbl_daftarpengeluaranrill.uraian')
			->get()->result();
	}

	public function cetaklaporanmaksud($id_sppd)
	{
		$this->db->where('id_sppd', $id_sppd);
        return $this->db->from('tbl_laporanmaksud')
			->get()->result();
	}

	public function pelaksana()
	{
		$nip = $this->session->userdata('nip');
		$this->db->where('tbl_pegawai.nip', $nip);
		$this->db->order_by('tbl_riwayat_kepangkatan.tanggal_sk', "DESC");
		$this->db->order_by('tbl_riwayat_jabatan.tanggal_sk', "DESC");
		$this->db->limit(1);
        return $this->db->from('tbl_pegawai')
		->join('tbl_riwayat_kepangkatan','tbl_riwayat_kepangkatan.nip=tbl_pegawai.nip')
		->join('tbl_riwayat_jabatan','tbl_riwayat_jabatan.nip=tbl_pegawai.nip')
			->get()->row();
	}

	public function daftarpengeluaran($tanggal_mulai,$tanggal_sampai,$id_opd)
	{
		$this->db->select('*');
		$this->db->where('tbl_pegawai.id_opd',$id_opd);
		$this->db->where('tbl_sppd.tanggal_sppd >=', $tanggal_mulai);
		$this->db->where('tbl_sppd.tanggal_sppd <=', $tanggal_sampai);
        return $this->db->from('tbl_daftarpengeluaran')
		->join('tbl_detailsppd','tbl_detailsppd.id_detailsppd=tbl_daftarpengeluaran.id_detailsppd')
		->join('tbl_sppd','tbl_sppd.id_sppd=tbl_detailsppd.id_sppd')
		->join('tbl_pegawai','tbl_pegawai.nip=tbl_detailsppd.nip')
		->join('tbl_riwayat_jabatan','tbl_riwayat_jabatan.nip=tbl_detailsppd.nip')
		->join('tbl_riwayat_kepangkatan','tbl_riwayat_kepangkatan.nip=tbl_detailsppd.nip')
			->get()->result();
	}

	public function daftarpengeluaran_periodelalu($tanggal_mulai,$id_opd)
	{
		$awal_tahun = date("Y/01/01",strtotime($tanggal_mulai));
		$this->db->select_sum('uangharian');
		$this->db->select_sum('representasi');
		$this->db->select_sum('tiket_angkutan_darat');
		$this->db->select_sum('keb_basicfare');
		$this->db->select_sum('ked_basicfare');
		$this->db->select_sum('keb_taxes');
		$this->db->select_sum('ked_taxes');
		$this->db->select_sum('taxi');
		$this->db->select_sum('biaya_kontribusi');
		$this->db->where('tbl_pegawai.id_opd',$id_opd);
		$this->db->where('tbl_sppd.tanggal_sppd >=', $awal_tahun);
		$this->db->where('tbl_sppd.tanggal_sppd <', $tanggal_mulai);
        return $this->db->from('tbl_daftarpengeluaran')
		->join('tbl_detailsppd','tbl_detailsppd.id_detailsppd=tbl_daftarpengeluaran.id_detailsppd')
		->join('tbl_sppd','tbl_sppd.id_sppd=tbl_detailsppd.id_sppd')
		->join('tbl_pegawai','tbl_pegawai.nip=tbl_detailsppd.nip')
			->get()->row_array();
	}

	public function daftarpengeluaran_periodeini($tanggal_sampai,$id_opd)
	{
		$awal_tahun = date("Y/01/01",strtotime($tanggal_sampai));
		$this->db->select_sum('uangharian');
		$this->db->select_sum('representasi');
		$this->db->select_sum('tiket_angkutan_darat');
		$this->db->select_sum('keb_basicfare');
		$this->db->select_sum('ked_basicfare');
		$this->db->select_sum('keb_taxes');
		$this->db->select_sum('ked_taxes');
		$this->db->select_sum('taxi');
		$this->db->select_sum('biaya_kontribusi');
		$this->db->where('tbl_pegawai.id_opd',$id_opd);
		$this->db->where('tbl_sppd.tanggal_sppd >=', $awal_tahun);
		$this->db->where('tbl_sppd.tanggal_sppd <=', $tanggal_sampai);
        return $this->db->from('tbl_daftarpengeluaran')
		->join('tbl_detailsppd','tbl_detailsppd.id_detailsppd=tbl_daftarpengeluaran.id_detailsppd')
		->join('tbl_sppd','tbl_sppd.id_sppd=tbl_detailsppd.id_sppd')
		->join('tbl_pegawai','tbl_pegawai.nip=tbl_detailsppd.nip')
		->get()->row_array();
	}

	public function cetaksppddalam($tanggal_mulai,$tanggal_sampai,$id_opd)
	{
		$this->db->where('tbl_sppd.tanggal_sppd >=', $tanggal_mulai);
		$this->db->where('tbl_sppd.tanggal_sppd <=', $tanggal_sampai);
		$this->db->where('tbl_sppd.dinas', "Dinas Dalam");
		$this->db->where('tbl_pegawai.id_opd', $id_opd);
        return $this->db->from('tbl_detailsppd')
			->join('tbl_pegawai','tbl_pegawai.nip=tbl_detailsppd.nip')
			->join('tbl_sppd','tbl_sppd.id_sppd=tbl_detailsppd.id_sppd')
			->get();
	}

	public function cetaksppddalam_periodelalu($tanggal_mulai,$id_opd)
	{
		$awal_tahun = date("Y/01/01",strtotime($tanggal_mulai));
		$this->db->where('tbl_sppd.tanggal_sppd >=', $awal_tahun);
		$this->db->where('tbl_sppd.tanggal_sppd <', $tanggal_mulai);
		$this->db->where('tbl_sppd.dinas', "Dinas Dalam");
		$this->db->where('tbl_pegawai.id_opd', $id_opd);
        return $this->db->from('tbl_detailsppd')
			->join('tbl_pegawai','tbl_pegawai.nip=tbl_detailsppd.nip')
			->join('tbl_sppd','tbl_sppd.id_sppd=tbl_detailsppd.id_sppd')
			->get();
	}

	public function cetaksppddalam_periodeini($tanggal_sampai,$id_opd)
	{
		$awal_tahun = date("Y/01/01",strtotime($tanggal_sampai));
		$this->db->where('tbl_sppd.tanggal_sppd >=', $awal_tahun);
		$this->db->where('tbl_sppd.tanggal_sppd <=', $tanggal_sampai);
		$this->db->where('tbl_sppd.dinas', "Dinas Dalam");
		$this->db->where('tbl_pegawai.id_opd', $id_opd);
        return $this->db->from('tbl_detailsppd')
			->join('tbl_pegawai','tbl_pegawai.nip=tbl_detailsppd.nip')
			->join('tbl_sppd','tbl_sppd.id_sppd=tbl_detailsppd.id_sppd')
			->get();
	}
	
}

/* End of file model_login.php */
/* Location: ./application/models/model_login.php */