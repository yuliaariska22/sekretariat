<?php 
$this->load->view('include/header'); 
?>

<main id="main">
  <section id="hero">
    <div class="hero-container" data-aos="fade-in"> 
    <div class="container">
      
        <div class="row">
          <div class="col-md-6 col-lg-3" data-aos="zoom-in" data-aos-delay="100">
            <div class="feature-block">

              <img src="<?php echo base_url(); ?>assets/img/svg/cloud.svg" alt="img" class="img-fluid">
              <h4 class="title"><a href="<?= base_url('pegawai/datadiri'); ?>">Data Diri</a></h4>
              <h4 class="title"><a href="<?= base_url('pegawai/keluarga'); ?>">Data Keluarga</a></h4>        
                        <h4 class="title"><a href="<?= base_url('pegawai/drh_keteranganlain'); ?>"> Keterangan Lain </a></h4>
      
            </div>
          </div>
          <div class="col-md-6 col-lg-6" data-aos="zoom-in" data-aos-delay="200">
            <div class="feature-block">

              <img src="<?php echo base_url(); ?>assets/img/svg/planet.svg" alt="img" class="img-fluid">
              <h4 class="title"><a href="<?= base_url('pegawai/pendidikan'); ?>"> Pendidikan</a></h4>
              <h4 class="title"><a href="<?= base_url('pegawai/kursus'); ?>"> Kursus</a></h4>
              <h4 class="title"><a href="<?= base_url('pegawai/pelatihan'); ?>"> Pelatihan</a></h4>
              <h4 class="title"><a href="<?= base_url('pegawai/organisasi'); ?>"> Organisasi</a></h4>
              <h4 class="title"><a href="<?= base_url('pegawai/penghargaan'); ?>"> Tanda Jasa/Penghargaan</a></h4>
              <h4 class="title"><a href="<?= base_url('pegawai/pengalaman_luarnegeri'); ?>"> Pengalaman Luar Negeri</a></h4>
              <h4 class="title"><a href="<?= base_url('pegawai/penyaji'); ?>">Pengalaman Penyaji Seminar/Lokakarya</a></h4>
              <h4 class="title"><a href="<?= base_url('pegawai/karyatulis'); ?>">Buku/Karya Tulis/Makalah</a></h4>
            </div>
          </div>

          <div class="col-md-6 col-lg-3" data-aos="zoom-in" data-aos-delay="300">
            <div class="feature-block">
              <img src="<?php echo base_url(); ?>assets/img/svg/asteroid.svg" alt="img" class="img-fluid">
              <h4 class="title"><a href="<?= base_url('pegawai/riwayat_jabatan'); ?>"> Riwayat Jabatan</a></h4>
              <h4 class="title"><a href="<?= base_url('pegawai/riwayat_kepangkatan'); ?>"> Riwayat Kepangkatan</a></h4>
              <h4 class="title"><a href="<?= base_url('pegawai/du_kepangkatan'); ?>"> Daftar Urut Kepangkatan</a></h4>
              <h4 class="title"><a href="<?= base_url('pegawai/skp'); ?>"> DP3/SKP</a></h4>
              <h4 class="title"><a href="<?= base_url('pegawai/disiplin'); ?>"> Disiplin</a></h4>
   
     </div>
          </div>

        </div>
        
</div>


      </div>
  </section><!-- End Hero Section -->

 
  </main>
</div>


</div>
<?php 
$this->load->view('include/footer'); 
?>  