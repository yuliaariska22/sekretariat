<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Aplikasi Penatausahaan Keuangan - Index</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?php echo base_url(''); ?>assets/img/favicon.png" rel="icon">
  <link href="<?php echo base_url(''); ?>assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Roboto:100,300,400,500,700|Philosopher:400,400i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo base_url(''); ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url(''); ?>assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="<?php echo base_url(''); ?>assets/vendor/modal-video/css/modal-video.min.css" rel="stylesheet">
  <link href="<?php echo base_url(''); ?>assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="<?php echo base_url(''); ?>assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo base_url(''); ?>assets/css/style.css" rel="stylesheet">

  <link href="<?php echo base_url().'assets/css/jquery.datatables.min.css'?>" rel="stylesheet" type="text/css"/>
  <link href="<?php echo base_url().'assets/css/dataTables.bootstrap.css'?>" rel="stylesheet" type="text/css"/>

  <!-- =======================================================
  * Template Name: eStartup - v2.2.1
  * Template URL: https://bootstrapmade.com/estartup-bootstrap-landing-page-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<?php 
$nip = $this->session->userdata('nip');


//PEGAWAI

$cetakbiodata = $this->db->query("SELECT * FROM tbl_pegawai where nip=$nip and status_verifikasi='Sudah Diverifikasi'")->row();
if ($cetakbiodata != NULL){
  $url_cetakbiodata = "pegawai/cetakbiodata";
}else{
  $url_cetakbiodata = "welcome";
}

$cetakdrh = $this->db->query("SELECT * FROM tbl_pegawai where nip=$nip and status_verifikasi='Sudah Diverifikasi'")->row();
if ($cetakdrh != NULL){
  $url_cetakdrh = "pegawai/cetakdaftarriwayathidup";
}else{
  $url_cetakdrh = "welcome";
}


$verifikasidatapegawai = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- Pegawai - Verifikasi Data Pegawai'")->row();
if ($verifikasidatapegawai != NULL){
  $url_verifikasidatapegawai = "pegawai/verifikasidatapegawai";
}else{
  $url_verifikasidatapegawai = "welcome";
}

//SPPD
$pengajuansppd = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- SPPD - Pengajuan SPPD'")->row();
if ($pengajuansppd != NULL){
  $url_pengajuansppd = "sppd/pengajuansppd";
}else{
  $url_pengajuansppd = "welcome";
}

$rekapitulasisppd = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- SPPD - Laporan SPPD'")->row();
if ($rekapitulasisppd != NULL){
  $url_rekapitulasisppd = "sppd/rekapitulasisppd";
}else{
  $url_rekapitulasisppd = "welcome";
}

$rekapitulasisppdtransportasiudara = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- SPPD - Laporan SPPD'")->row();
if ($rekapitulasisppdtransportasiudara != NULL){
  $url_rekapitulasisppdtransportasiudara = "sppd/rekapitulasisppdtransportasiudara";
}else{
  $url_rekapitulasisppdtransportasiudara = "welcome";
}

$rekapitulasibiayapenginapan = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- SPPD - Laporan SPPD'")->row();
if ($rekapitulasibiayapenginapan != NULL){
  $url_rekapitulasibiayapenginapan = "sppd/rekapitulasibiayapenginapan";
}else{
  $url_rekapitulasibiayapenginapan = "welcome";
}

$rekapitulasisppddalamdaerah = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- SPPD - Laporan SPPD'")->row();
if ($rekapitulasisppddalamdaerah != NULL){
  $url_rekapitulasisppddalamdaerah = "sppd/rekapitulasisppddalamdaerah";
}else{
  $url_rekapitulasisppddalamdaerah = "welcome";
}

$laporanperjalanandinas = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- SPPD - Laporan Perjalanan Dinas'")->row();
if ($laporanperjalanandinas != NULL){
  $url_laporanperjalanandinas = "sppd/laporanperjalanandinas";
}else{
  $url_laporanperjalanandinas = "welcome";
}

//Aset
$kiba = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- Aset - KIB A'")->row();
if ($kiba != NULL){
  $url_kiba = "aset/kiba";
}else{
  $url_kiba = "welcome";
}

$kibb = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- Aset - KIB B'")->row();
if ($kibb != NULL){
  $url_kibb = "aset/kibb";
}else{
  $url_kibb = "welcome";
}

$laporanaset = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- Aset - Laporan Aset'")->row();
if ($laporanaset != NULL){
  $url_laporankiba_r = "aset/rekapkiba";
  $url_laporankiba_g = "aset/globalkiba";
  $url_laporankiba_o = "aset/opdkiba";
  $url_laporankiba_d = "aset/daftarkiba";
  $url_laporankiba_t = "aset/tanahkiba";
  $url_laporankibb_r = "aset/rekapkibb";
  $url_laporankibb_g = "aset/globalkibb";
  $url_laporankibb_o = "aset/opdkibb";
  $url_laporankibb_h = "aset/hilangkibb";
  $url_laporankibb_j = "aset/jeniskendaraankibb";
  $url_laporankibb_p = "aset/penambahankibb";
}else{
  $url_laporankiba_r = "welcome";
  $url_laporankiba_g = "welcome";
  $url_laporankiba_o = "welcome";
  $url_laporankiba_d = "welcome";
  $url_laporankiba_t = "welcome";
  $url_laporankibb_r = "welcome";
  $url_laporankibb_g = "welcome";
  $url_laporankibb_o = "welcome";
  $url_laporankibb_h = "welcome";
  $url_laporankibb_j = "welcome";
  $url_laporankibb_p = "welcome";
}





//Barang Persediaan


//pengadaan

$pengajuanpengadaan = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- Barang Persediaan - Pengajuan Pengadaan'")->row();
if ($pengajuanpengadaan != NULL){
  $url_pengajuanpengadaan = "barangpersediaan/pengajuanpengadaan";
}else{
  $url_pengajuanpengadaan = "welcome";
}


$cetaksuratpengadaan = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- Barang Persediaan - Cetak Surat Pengadaan'")->row();
if ($cetaksuratpengadaan != NULL){
  $url_cetaksuratpengadaan = "suratpengadaan";
}else{
  $url_cetaksuratpengadaan = "welcome";
}

$konfirmasipenerimaanbarang = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- Barang Persediaan - Konfirmasi Pengadaan'")->row();
if ($konfirmasipenerimaanbarang != NULL){
  $url_konfirmasipenerimaanbarang = "barangpersediaan/pengadaanpbp";
}else{
  $url_konfirmasipenerimaanbarang = "welcome";
}


$laporanpenerimaan = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- Barang Persediaan - Laporan Pengadaan'")->row();
if ($laporanpenerimaan != NULL){
  $url_laporanpenerimaan = "barangpersediaan/laporanpenerimaan";
  $url_laporanbuku = "barangpersediaan/laporanbuku";
  $url_laporanrekapitulasi = "barangpersediaan/laporanrekapitulasi";
}else{
  $url_laporanpenerimaan = "welcome";
  $url_laporanbuku = "welcome";
  $url_laporanrekapitulasi = "welcome";
}



//penyaluran

$pengajuanpenyaluran = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- Barang Persediaan - Pengajuan Permintaan Bidang'")->row();
if ($pengajuanpenyaluran != NULL){
  $url_pengajuanpenyaluran = "barangpersediaan/penyaluran";
}else{
  $url_pengajuanpenyaluran = "welcome";
}

$cetaksuratpenyaluran = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- Barang Persediaan - Cetak Surat Penyaluran'")->row();
if ($cetaksuratpenyaluran != NULL){
  $url_cetaksuratpenyaluran = "suratpenyaluran";
}else{
  $url_cetaksuratpenyaluran = "welcome";
}

$konfirmasipenyaluranbarang = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- Barang Persediaan - Konfirmasi Penyaluran'")->row();
if ($konfirmasipenyaluranbarang != NULL){
  $url_konfirmasipenyaluranbarang = "barangpersediaan/penyaluranpbp";
}else{
  $url_konfirmasipenyaluranbarang = "welcome";
}


$laporanpenyaluran = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- Barang Persediaan - Laporan Penyaluran'")->row();
if ($laporanpenyaluran != NULL){
  $url_laporanpengeluaran = "barangpersediaan/laporanpengeluaran";
  $url_laporanbukupeny = "barangpersediaan/laporanbukupeny";
  $url_laporanrekapitulasipeny = "barangpersediaan/laporanrekapitulasipeny";
}else{
  $url_laporanpengeluaran = "welcome";
  $url_laporanbukupeny = "welcome";
  $url_laporanrekapitulasipeny = "welcome";
}





//Pengaturan
$menu = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- Pengaturan - Menu'")->row();
if ($menu != NULL){
  $url_menu = "pengaturan/menu";
}else{
  $url_menu = "welcome";
}

$pembebanananggaran = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- Pengaturan - Pembebanan Anggaran'")->row();
if ($pembebanananggaran != NULL){
  $url_pembebanananggaran = "pengaturan/pembebanananggaran";
}else{
  $url_pembebanananggaran = "welcome";
}

$suratkeputusan = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- Pengaturan - Surat Keputusan'")->row();
if ($suratkeputusan != NULL){
  $url_suratkeputusan = "pengaturan/suratkeputusan";
}else{
  $url_suratkeputusan = "welcome";
}

$ssh = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- Pengaturan - SSH'")->row();
if ($ssh != NULL){
  $url_ssh = "pengaturan/ssh";
}else{
  $url_ssh = "welcome";
}

$rekanan = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- Pengaturan - Rekanan'")->row();
if ($rekanan != NULL){
  $url_rekanan = "pengaturan/rekanan";
}else{
  $url_rekanan = "welcome";
}

$satuanhargarekanan = $this->db->query("SELECT * FROM tbl_menu where nip=$nip and menu='- Pengaturan - Satuan Harga Rekanan'")->row();
if ($satuanhargarekanan != NULL){
  $url_satuanhargarekanan = "pengaturan/spj";
}else{
  $url_satuanhargarekanan = "welcome";
}
?>
<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header">
    <div class="container">

      <div id="logo" class="pull-left">
        <h1><a href="<?php echo base_url('welcome'); ?>"><span>Aplikasi</span> Penatausahaan Keuangan</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html"><img src="<?php echo base_url(''); ?>assets/img/logo.png" alt="" title="" /></a>-->
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="<?php echo base_url('welcome'); ?>">Home</a></li>
          <li class="menu-has-children"><a href="">Pegawai</a>
            <ul>
              <li class="menu-has-children"><a href="">Data Pribadi</a>
                <ul>
                <li><a href="<?= base_url('pegawai/datapribadi'); ?>">Input Data Pribadi</a></li>
                <li><a href="<?= base_url($url_cetakbiodata); ?>">Cetak Biodata</a></li>
                <li><a href="<?= base_url($url_cetakdrh); ?>">Cetak Daftar Riwayat Hidup</a></li>
                </ul>
              </li>
              <li><a href="<?= base_url($url_verifikasidatapegawai); ?>">Verifikasi Data Pegawai</a></li>
            </ul>
          </li>
         
          <li class="menu-has-children"><a href="">SPPD</a>
            <ul>
              <li><a href="<?= base_url($url_pengajuansppd); ?>">Pengajuan SPPD</a></li>
              <li><a href="<?= base_url($url_laporanperjalanandinas); ?>">Laporan Perjalanan Dinas</a></li>
              <li class="menu-has-children"><a href="">Laporan SPPD</a>
              <ul>
              <li><a href="<?= base_url($url_rekapitulasisppd); ?>">Rekapitulasi SPPD</a></li>
              <li><a href="<?= base_url($url_rekapitulasisppdtransportasiudara);?>">Rekapitulasi Transportasi Udara</a></li>
              <li><a href="<?= base_url($url_rekapitulasibiayapenginapan); ?>">Rekapitulasi Biaya Penginapan</a></li>
              <li><a href="<?= base_url($url_rekapitulasisppddalamdaerah); ?>">Rekapitulasi SPPD Dalam Daerah</a></li>
              </ul></li>
              </ul>
          </li>
          <li class="menu-has-children"><a href="<?php echo base_url('welcome'); ?>">Aset</a>
            <ul>
              <li><a href="<?= base_url($url_kiba); ?>">KIB A</a></li>
              <li class="menu-has-children"><a href="">Laporan KIB A</a>
              <ul>
              <li><a href="<?= base_url($url_laporankiba_r); ?>">Rekap</a></li>
              <li><a href="<?= base_url($url_laporankiba_g); ?>">Global</a></li>
              <li><a href="<?= base_url($url_laporankiba_o); ?>">OPD</a></li>
              <li><a href="<?= base_url($url_laporankiba_d); ?>">Daftar</a></li>
              <li><a href="<?= base_url($url_laporankiba_t); ?>">Tanah</a></li>
              </ul>
              <li><a href="<?= base_url($url_kibb); ?>">KIB B</a> </li>
              <li class="menu-has-children"><a href="">Laporan KIB B</a>
              <ul>
              <li><a href="<?= base_url($url_laporankibb_r); ?>"> Rekap</a></li>
              <li><a href="<?= base_url($url_laporankibb_g); ?>"> Global</a></li>
              <li><a href="<?= base_url($url_laporankibb_o); ?>"> OPD</a></li>
              <li><a href="<?= base_url($url_laporankibb_h); ?>"> Hilang</a></li>
              <li><a href="<?= base_url($url_laporankibb_j); ?>"> Jenis Kendaraan</a></li>
              <li><a href="<?= base_url($url_laporankibb_p); ?>"> Penambahan</a></li>
              </ul>
              </li>
          </ul></li>
            
          <li class="menu-has-children"><a href="">Barang Persediaan</a>
            <ul>
              <li class="menu-has-children"><a href="">Pengadaan</a>
              <ul>
              <li><a href="<?= base_url($url_pengajuanpengadaan); ?>">Pengajuan Pengadaan</a></li>
              <li><a href="<?= base_url($url_cetaksuratpengadaan); ?>">Cetak Surat Pengadaan</a></li>
              <li><a href="<?= base_url($url_konfirmasipenerimaanbarang); ?>">Konfirmasi Pengadaan</a></li>
                </ul>
           
              <li class="menu-has-children"><a href="">Laporan Pengadaan</a>
              <ul>
              <li><a href="<?= base_url($url_laporanpenerimaan); ?>">Penerimaan</a></li>
              <li><a href="<?= base_url($url_laporanbuku); ?>">Buku</a></li>
              <li><a href="<?= base_url($url_laporanrekapitulasi); ?>">Rekapitulasi</a></li>
            </ul></li>

            <li class="menu-has-children"><a href="">Penyaluran</a>
              <ul>
              <li><a href="<?= base_url($url_pengajuanpenyaluran); ?>">Pengajuan Permintaan Bidang</a></li>
              <li><a href="<?= base_url($url_cetaksuratpenyaluran); ?>">Cetak Surat Penyaluran</a></li>
              <li><a href="<?= base_url($url_konfirmasipenyaluranbarang); ?>">Konfirmasi Penyaluran</a></li>
            
                </ul>
            </li>

            <li class="menu-has-children"><a href="">Laporan Penyaluran</a>
              <ul>
              <li><a href="<?= base_url($url_laporanpengeluaran);?>">Pengeluaran</a></li>
              <li><a href="<?= base_url($url_laporanbukupeny); ?>">Buku</a></li>
              <li><a href="<?= base_url($url_laporanrekapitulasipeny); ?>">Rekapitulasi</a></li>
            </ul></li>

            </ul>
          </li>
          <li class="menu-has-children"><a href="">Pengaturan</a>
            <ul>
              <li><a href="<?= base_url($url_menu); ?>">Menu</a></li>
              <li><a href="<?= base_url($url_pembebanananggaran); ?>">Pembebanan Anggaran</a></li>
              <li><a href="<?= base_url($url_suratkeputusan); ?>">Surat Keputusan</a></li>
              <li><a href="<?= base_url($url_ssh); ?>">SSH</a></li>
              <li><a href="<?= base_url($url_rekanan); ?>">Rekanan</a></li>
           
            </ul>
          </li>
          <li><a href="<?php echo base_url('login/logout'); ?>">Logout</a></li>
        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- End Header -->