<?php 
$this->load->view('include/header'); 
?>
<table>
<tr height="50px"><td></td></tr>
</table>
  <!-- ======= Hero Section ======= -->
  <section id="hero">
    <div class="hero-container" data-aos="fade-in">
      <h1>Selamat Datang, <?= $this->session->userdata('nama');?> !</h1>
      <h2>   </h2>
      <img src="assets/img/hero-img.png" alt="Hero Imgs" data-aos="zoom-out" data-aos-delay="100">
     
     
    </div>
  </section><!-- End Hero Section -->

  <main id="main">


  


    <!-- ======= Contact Section ======= -->
    <section id="contact" class="padd-section">

      <div class="container" data-aos="fade-up">
        <div class="section-title text-center">
          <h2>Kontak Kami</h2>
          <p class="separator">Hubungi kontak di bawah ini untuk bantuan</p>
        </div>

        <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="100">

          <div class="col-lg-3 col-md-4">

            <div class="info">
              <div>
                <i class="fa fa-map-marker"></i>
                <p>Jln. Jen. Dr. Abd.Haris Nasution Pal - IV Pijorkoling<br>Sumatera Utara, Indonesia</p>
              </div>

              <div class="email">
                <i class="fa fa-envelope"></i>
                <p>bakeudasidimpuan@gmail.com</p>
              </div>

              <div>
                <i class="fa fa-phone"></i>
                <p>(0634)27075</p>
              </div>
            </div>

            <div class="social-links">
              <a href="" class="twitter"><i class="fa fa-twitter"></i></a>
              <a href="" class="facebook"><i class="fa fa-facebook"></i></a>
              <a href="" class="instagram"><i class="fa fa-instagram"></i></a>
              <a href="" class="google-plus"><i class="fa fa-google-plus"></i></a>
              <a href="" class="linkedin"><i class="fa fa-linkedin"></i></a>
            </div>

          </div>

        </div>
      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

<?php 
$this->load->view('include/footer'); 
?>  